# TCC2

Este é um projeto de conclusão de curso feito por Larissa Balera e Luiz Felipe.

# Indice de tags
# : Objetivos Principais (Páginas em geral, funções importantes para funcionamento do site)
# . Objetivos Secundários (Problemas em estilo, javascript faltando, problemas em geral)
# ! Importante (Grau de importância acima de objetivos sem !, mas não quebram a hierarquia de principal/secundario, exemplo: .objetivo!)
# Caso queira adicionar mais tags, só me avisa depois de colocar elas.

   /-Já feito-/

Página inicial

   14/05/2018

cadastro.php substituido

Inserido o jQuery de cep em um .js a parte, bem como algumas linhas de comando impedindo a inserção do comando ENTER para enviar o campo de formulário.

Labels arrumadas

   15/05/2018

Inicio de testes em base.php; Principais funções do cadastro implementadas.

   18/05/2018

Novo visual para página inicial, modal para login feito, base.php atualizado

   20/05/2018 - 21/05/2018

Pagina inicial finalizada (falta estilizar), cadastro finalizado (falta estilizar), nova sidebar, começo da homepage

   22/05/2018

Barra lateral mudada

   23/05 - 27/05

Várias telas

   28/05/2018

Mexendo na sidebar DENOVO

   /-Sendo Feito-/

   ???

   /-Para Arrumar-/

Os redirecionamentos da sidebar
Regras de cadastro
