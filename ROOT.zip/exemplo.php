<div class='panel panel-default'>
  <div class='panel-heading' role='tab' id='heading"+count+"'>
   <h4 class='panel-title'>
    <div>
     <a role='button' data-toggle='collapse' data-parent='#accordion' href='#collapse"+count+"' aria-expanded='true' aria-controls='collapse"+count+"' id='nome-etapa'>
      <span>Etapa #"+count+"</span>
    </a>
    <button type='button' id='edita-etapa' class='btn-edicao'> <img class='img-etapa-edicao' src='img/edit-file.png'>
    </button>
  </div> 
</h4> 
</div>
<div id='collapse"+count+"' class='panel-collapse collapsein' role='tabpanel' aria-labelledby='heading"+count+"'>
  <div class='acordion-strow'>
   <div class='col-md-4'>
    <label>Atividade #"+count+"</label>
    <input type='text'name=''>
  </div> 
</div>
</div> 
</div>