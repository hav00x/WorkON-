  <!-- Rodape -->
  <footer id="rodape">
    <div class="container">
      <div class="row">
          <div class="col-md-12">
            <p style="color: white; text-align: center;">WORKON! | sua plataforma de projetos!</p>
            <p style="text-align: center;">Desenvolvido por <a href="mailto:larissa.balera@live.com">Larissa Balera</a> e
           <a href="mailto:felipefalchibarreto@hotmail.com">Luiz Felipe</a>,
          </div>
      </div><!-- /row -->
    </div>
  </footer>