<!-- BARRA DE NAVEGAÇÃO -->
  <div class="container">
    <!-- header -->
    
  </div>
  <div class="section row">
      <div class="col-md-4">
        <h3>Olá mundo</h3>
      </div>
      <div class="col-md-4">
        <form action="" method="">
          <input type="submit" name="OK" value="OK" class="button-hp" placeholder="Pesquisar. . .">
          <div class="input"><input id="input-homepage" type="text" name="search"></div>
        </form>
      </div>

      <div class="col-md-4">
         <a style="margin: 13px;" class="button-hp" href="sair.php">SAIR</a>
        </div>
    </div>